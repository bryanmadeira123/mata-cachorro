# Não Clique Aqui 😂 — versão completa

Este jogo está em um único arquivo (`index.html`): HTML, CSS e JavaScript já estão juntos. Não precisa instalar nada nem enviar outros arquivos.

## Testar no computador
1. Extraia o ZIP.
2. Abra a pasta `pegadinha_memes_completo`.
3. Dê dois cliques em `index.html` para abrir no navegador.

## Publicar no GitHub Pages
1. Entre em https://github.com/new e crie um repositório **Public** chamado `pegadinha-memes`.
2. Dentro do repositório, clique em **Add file → Upload files**.
3. Envie o `index.html` que está nesta pasta e clique em **Commit changes**.
4. Vá em **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**.
6. Selecione a branch `main` e a pasta `/(root)`, depois clique em **Save**.
7. Aguarde alguns minutos. O endereço será `https://SEU-USUARIO.github.io/pegadinha-memes/`, substituindo `SEU-USUARIO` pelo seu nome de usuário do GitHub.

O link público só existe depois que você publicar o arquivo no seu próprio GitHub. Não compartilhe senha nem códigos de acesso.
